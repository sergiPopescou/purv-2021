#ifndef __DRV_MOUSE_H__
#define __DRV_MOUSE_H__

int rt_hw_mouse_init(void);

#endif