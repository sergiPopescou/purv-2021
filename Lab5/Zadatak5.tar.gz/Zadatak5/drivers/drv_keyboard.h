#ifndef __DEV_KEYBOARD_H__
#define __DEV_KEYBOARD_H__

int rt_hw_keyboard_init(void);

#endif
